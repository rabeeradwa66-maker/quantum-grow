import asyncio
from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart
from aiogram.types import Message, WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton
from .config import settings

dp = Dispatcher()

@dp.message(CommandStart())
async def start(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="فتح Quantum Grow",
            web_app=WebAppInfo(url=settings.webapp_url)
        )
    ]])
    await message.answer(
        "مرحبًا بك في Quantum Grow 👋\n\n"
        "هذه النسخة التجريبية توفر واجهة الحساب والمحفظة والاستثمار. "
        "لا يتم حفظ أموال العملاء أو ضمان أرباح في هذه النسخة.",
        reply_markup=kb
    )

async def main():
    bot = Bot(settings.telegram_bot_token)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
