from fastapi import FastAPI
from fastapi.responses import FileResponse
from .db import Base, engine
from . import models

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Quantum Grow API", version="0.1.0")

@app.get("/health")
def health():
    return {"status": "ok", "project": "Quantum Grow"}

@app.get("/api/dashboard")
def dashboard():
    return {
        "project": "Quantum Grow",
        "balance": 0,
        "currency": "USD",
        "invested": 0,
        "pnl": 0,
        "notice": "Demo mode: no real-money custody or guaranteed returns."
    }

@app.get("/")
def webapp():
    return FileResponse("web/index.html")
